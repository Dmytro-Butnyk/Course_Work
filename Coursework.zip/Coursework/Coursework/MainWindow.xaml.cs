﻿using System.Windows;
using Coursework.ViewModel;
using Coursework.Model;


namespace Coursework
{
    

    public partial class MainWindow : Window
    {
    private DataService dataService;


        public MainWindow()
        {
            InitializeComponent();
            dataService = new DataService();
            ViewModelMain viewModel = new ViewModelMain(dataService);
            this.DataContext = viewModel;
            viewModel.Frame = InfoFrame;
        }
 
    }
}
