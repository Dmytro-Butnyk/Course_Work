﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;

namespace Coursework.Model
{
    public class Arcane
    {
        public int A_Num {get; set;}
        public string? A_Name { get; set;}
        public string? A_General_Description { get; set;}
        public string? A_Detailed_Description { get; set;}
        public string? A_Path_Image { get; set;}
        public Arcane(int number, string name, string general, string detailed, string path) {
            A_Num = number;
            A_Name = name;
            A_General_Description = general;
            A_Detailed_Description = detailed;
            A_Path_Image = path;
        }
        public Arcane() { }

        public override string ToString()
        {
            return $"{A_Num}:{A_Name}:\n{A_General_Description}";
        }

    }
}
