﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Coursework.Model
{
    public class DataService : INotifyPropertyChanged
    {
        public Matrix_Individual matrix1 {  get; set; }
        public Matrix_Individual matrix2 { get; set; }
        public int _index { get; set; }
        public string _user_name { get; set; }
        public class Matrix_Indivdual
        {
            public int MyProperty { get; set; }
        }
        public int Index
        {
            get { return _index; }
            set
            {
                if (_index != value)
                {
                    _index = value;
                    OnPropertyChanged(nameof(Index));
                }
            }
        }
        public string User_Name
        {
            get { return _user_name; }
            set
            {
                if (_user_name != value)
                {
                    _user_name = value;
                    OnPropertyChanged(nameof(User_Name));
                }
            }
        }
        public Info InfoFrame {get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
