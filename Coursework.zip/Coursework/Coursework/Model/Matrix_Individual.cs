﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO.Packaging;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Coursework.Model
{
    public class Matrix_Individual : INotifyPropertyChanged
    {
        public int _Date_Day;
        private int _Date_Month;
        private int _Date_Year;
        public int Date_Day
        {
            get { return _Date_Day; }
            set
            {
                _Date_Day = value;
                OnPropertyChanged("Date_Day");
            }
        }
        public int Date_Month
        {
            get
            {
                return _Date_Month;
            }
            set
            {
                _Date_Month = value;
                OnPropertyChanged("Date_Month");
            }
        } 
        public int Date_Year
        {
            get { return _Date_Year; }
            set
            {
                _Date_Year = value;
                OnPropertyChanged("Date_Year");
            }
        }
        public int ParseCenter()
        {
            int center = Date_Month;

            if (Date_Day > 22)
            {
                center += Date_Day / 10 + Date_Day % 10;
            }
            else
            {
                center += Date_Day;
            }

            string parsedYear = (Date_Year / 1000 + (Date_Year / 100) % 10 + (Date_Year / 10) % 10 + Date_Year % 10).ToString();

            int sum = 0;
            foreach (char digit in parsedYear)
            {
                sum += int.Parse(digit.ToString());
            }

            center += sum;
            center *= 2;
            if(center > 22) center = center / 10 + center % 10;

            return center;
        }
        public int[] ParseTalents()
        {

            int[] talents = new int[3];
            talents[0] = Date_Month;
            talents[1] = talents[0] + ParseCenter();
            if (talents[1] > 22) talents[1] = talents[1] / 10 + talents[1] % 10;

            talents[2] = talents[1] + talents[0];
            if (talents[2] > 22) talents[2] = talents[2] / 10 + talents[2] % 10;


            return talents;
        }
        public int[] ParsePortret()
        {
            string Day = _Date_Day.ToString();

            int[] portret = new int[3];
            if (int.Parse(Day) > 22)
            {
                portret[0] = int.Parse(Day[0].ToString()) + int.Parse(Day[1].ToString());
            }
            else
            {
                portret[0] += int.Parse(Day);
            }

            portret[1] = portret[0] + ParseCenter();
            if (portret[1] > 22) portret[1] = portret[1] / 10 + portret[1] % 10;

            portret[2] = portret[1] + portret[0];
            if (portret[2] > 22) portret[2] = portret[2] / 10 + portret[2] % 10;


            return portret;
        }
        public int[] ParseFinance()
        {
            string year = _Date_Year.ToString();

            int[] finance = new int[3];

            int sumYear = year.Sum(digit => int.Parse(digit.ToString()));
            finance[0] = sumYear;

            if (finance[0] > 22) finance[0] = finance[0] / 10 + finance[0] % 10;

            finance[1] = finance[0] + ParseCenter();
            if (finance[1] > 22) finance[1] = finance[1] / 10 + finance[1] % 10;


            finance[2] = finance[1] + finance[0];
            if (finance[2] > 22) finance[2] = finance[2] / 10 + finance[2] % 10;

            return finance;
        }
        public int[] ParseTale()
        {
            int[] tale = new int[3];

            tale[0] = ParseTalents()[0] +
                ParsePortret()[0] + ParseFinance()[0];
            if (tale[0] > 22) tale[0] = tale[0] / 10 + tale[0] % 10;

            tale[1] = tale[0] + ParseCenter();
            if (tale[1] > 22) tale[1] = tale[1] / 10 + tale[1] % 10;
            tale[2] = tale[1] + tale[0];
            if (tale[2] > 22) tale[2] = tale[2] / 10 + tale[2] % 10;

            return tale;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
    }
}
