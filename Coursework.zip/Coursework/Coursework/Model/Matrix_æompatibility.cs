﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.IO.Packaging;
using System.Linq;
using System.Printing;
using System.Text;
using System.Threading.Tasks;

namespace Coursework.Model
{
    public class Matrix_Сompatibility
    {
        public Matrix_Individual first_person {get; set;}
        public Matrix_Individual second_person { get; set;}
        public Matrix_Сompatibility(Matrix_Individual? first_person, Matrix_Individual? second_person)
        {
            this.first_person = first_person;
            this.second_person = second_person;
        }
        public int ParseCenter()
        {
            int center = first_person.ParseCenter() +
                second_person.ParseCenter();

            if(center > 22 ) { 
                string temp = center.ToString();
                center = int.Parse(temp[0].ToString()) +
                    int.Parse(temp[1].ToString());
            }

            return center;
        }
        public int[] ParseTalents() {

            int[] talents = new int[3];

            talents[0] = first_person.ParseTalents()[0] + second_person.ParseTalents()[0];
            talents[0] = CheckValid(talents[0]);

            talents[1] = talents[0] + ParseCenter();
            talents[1] = CheckValid(talents[1]);

            talents[2] = talents[1] + talents[0];
            talents[2] = CheckValid(talents[2]);

            return talents;
        }
        public int[] ParsePortret()
        {
            int[] portret = new int[3];

            portret[0] = first_person.ParsePortret()[0] + second_person.ParsePortret()[0];
            portret[0] = CheckValid(portret[0]);

            portret[1] = portret[0] + ParseCenter();
            portret[1] = CheckValid(portret[1]);

            portret[2] = portret[1] + portret[0];
            portret[2] = CheckValid(portret[2]);

            return portret;
        }
        public int[] ParseFinance()
        {
            int[] finance = new int[3];

            finance[0] = first_person.ParseFinance()[0] + second_person.ParseFinance()[0];
            finance[0] = CheckValid(finance[0]);

            finance[1] = finance[0] + ParseCenter();
            finance[1] = CheckValid(finance[1]);

            finance[2] = finance[1] + finance[0];
            finance[2] = CheckValid(finance[2]);

            return finance;
        }
        public int[] ParseTale()
        {
            int[] tale = new int[3];

            tale[0] = first_person.ParseTale()[0] + second_person.ParseTale()[0];
            tale[0] = CheckValid(tale[0]);

            tale[1] = tale[0] + ParseCenter();
            tale[1] = CheckValid(tale[1]);

            tale[2] = tale[0] + tale[1];
            tale[2] = CheckValid(tale[2]);

        

            return tale;
        }
        public int CheckValid(int it)
        {
            if (it > 22) it = it / 10 + it % 10;
            return it;
        }
    }
}
