﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using Coursework.Model;

namespace Coursework.ViewModel
{
    public class ViewModelInformation : INotifyPropertyChanged
    {
        private DataService _dataService;
        private Matrix_Individual _matrix1;
        private Matrix_Individual _matrix2;
        private Matrix_Сompatibility _matrix3;
        private List<Arcane> _arcanes;
        private int _index;
        public int[] finance1;
        public int[] portret1;
        public int[] talents1;
        public int[] tale1;
        public int center1;
        public int[] finance2;
        public int[] portret2;
        public int[] talents2;
        public int[] tale2;
        public int center2;
        public ViewModelInformation(DataService dataService) {
            _dataService = dataService;
            _index = _dataService._index;
            _arcanes = ReadFromJsonFile();
            _matrix1 = _dataService.matrix1;
            _matrix2 = _dataService.matrix2;
            _matrix3 = new Matrix_Сompatibility(_dataService.matrix1, _dataService.matrix2);
            _user_name = _dataService.User_Name;
            GetData();
        }

        // Отримання данних з використанням інтерфейсу INotifyPropertyChanged

        private string _user_name;
        public string User_Name
        {
            get { return "Ім'я користувача: " + _user_name; }
            set
            {
                _user_name = value;
                OnPropertyChanged("User_Name");
            }
        }
        private StackPanel _matrix;
        public StackPanel Matrix
        {
            get => _matrix;
            set
            {
                _matrix = value;
                OnPropertyChanged(nameof(Matrix));
            }
        }
        private Button _PDF_button;
        public Button PDF_button
        {
            get => _PDF_button;
            set
            {
                _PDF_button = value;
                OnPropertyChanged(nameof(PDF_button));
            }
        }
        private Button _Back_ToMain;
        public Button Back_ToMain
        {
            get => _Back_ToMain;
            set
            {
                _Back_ToMain = value;
                OnPropertyChanged(nameof(Back_ToMain));
            }
        }
        private SPRelayCommand<StackPanel> _saveToPdfCommand;
        public SPRelayCommand<StackPanel> Save_To_PDF
        {
            get
            {
                return _saveToPdfCommand ?? (_saveToPdfCommand = new SPRelayCommand<StackPanel>(obj =>
                {
                    PDF_button.Visibility = Visibility.Collapsed;
                    Back_ToMain.Visibility = Visibility.Collapsed;
                    SaveToPdf(Matrix);
                    PDF_button.Visibility = Visibility.Visible;
                    Back_ToMain.Visibility = Visibility.Visible;

                }));
            }
        }
        private RelayCommand _backToMainWidow;
        public RelayCommand BackToMainWindow
        {
            get
            {
                return _backToMainWidow ?? (_backToMainWidow = new RelayCommand(obj =>
                {
                    _dataService.InfoFrame.Content = null;
                }));
            }
        }

        // Прив'язка даних
        // Текстблоки
        public string TextBlockCenter
        {
            get
            {
                bool exists = _arcanes.Any(x => x.A_Num == int.Parse(ContentCen));
                if (exists)
                    return "\n" + _arcanes[int.Parse(ContentCen) - 1].ToString();
                else return "Error";
            }
        }
        public string TextBlockTalents
        {
            get
            {
                bool exists1 = _arcanes.Any(x => x.A_Num == int.Parse(ContentTalents0));
                bool exists2 = _arcanes.Any(x => x.A_Num == int.Parse(ContentTalents1));
                if (exists1 && exists2)
                    return "\n" + _arcanes[int.Parse(ContentTalents0) - 1].ToString() +
                        "\n" + _arcanes[int.Parse(ContentTalents1) - 1].ToString();
                else return "Error";
            }
        }
        public string TextBlockPortret
        {
            get
            {
                bool exists1 = _arcanes.Any(x => x.A_Num == int.Parse(ContentPor0));
                bool exists2 = _arcanes.Any(x => x.A_Num == int.Parse(ContentPor1));
                if (exists1 && exists2)
                    return "\n" + _arcanes[int.Parse(ContentPor0) - 1].ToString() +
                       "\n" + _arcanes[int.Parse(ContentPor1) - 1].ToString();
                else return "Error";
            }
        }
        public string TextBlockFinance
        {
            get
            {
                bool exists1 = _arcanes.Any(x => x.A_Num == int.Parse(ContentFin0));
                bool exists2 = _arcanes.Any(x => x.A_Num == int.Parse(ContentFin1));
                if (exists1 && exists2)
                    return "\n" + _arcanes[int.Parse(ContentFin0) - 1].ToString() +
                        "\n" + _arcanes[int.Parse(ContentFin1) - 1].ToString();
                else return "Error";
            }
        }
        public string TextBlockTale
        {
            get
            {
                bool exists1 = _arcanes.Any(x => x.A_Num == int.Parse(ContentTale0));
                bool exists2 = _arcanes.Any(x => x.A_Num == int.Parse(ContentTale1));
                if (exists1 && exists2)
                    return "\n" + _arcanes[int.Parse(ContentTale0) - 1].ToString() +
                        "\n" + _arcanes[int.Parse(ContentTale1) - 1].ToString();
                else return "Error";
            }
        }
        // Лейбли
        public string ContentFin0 {
            get
            {
                if(_index == 0) return finance1[0].ToString();
                else return finance2[0].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = finance1[0].ToString();
                else s = finance2[0].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentFin1
        {
            get
            {
                if (_index == 0) return finance1[1].ToString();
                else return finance2[1].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = finance1[1].ToString();
                else s = finance2[1].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentFin2
        {
            get
            {
                if (_index == 0) return finance1[2].ToString();
                else return finance2[2].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = finance1[2].ToString();
                else s = finance2[2].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentPor0
        {
            get
            {
                if (_index == 0) return portret1[0].ToString();
                else return portret2[0].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = portret1[0].ToString();
                else s = portret2[0].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentPor1
        {
            get
            {
                if (_index == 0) return portret1[1].ToString();
                else return portret2[1].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = portret1[1].ToString();
                else s = portret2[1].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentPor2
        {
            get
            {
                if (_index == 0) return portret1[2].ToString();
                else return portret2[2].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = portret1[2].ToString();
                else s = portret2[2].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentTalents0
        {
            get
            {
                if (_index == 0) return talents1[0].ToString();
                else return talents2[0].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = talents1[0].ToString();
                else s = talents2[0].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentTalents1
        {
            get
            {
                if (_index == 0) return talents1[1].ToString();
                else return talents2[1].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = talents1[1].ToString();
                else s = talents2[1].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentTalents2
        {
            get
            {
                if (_index == 0) return talents1[2].ToString();
                else return talents2[2].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = talents1[2].ToString();
                else s = talents2[2].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentTale0
        {
            get
            {
                if (_index == 0) return tale1[0].ToString();
                else return tale2[0].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = tale1[0].ToString();
                else s = tale2[0].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentTale1
        {
            get
            {
                if (_index == 0) return tale1[1].ToString();
                else return tale2[1].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = tale1[1].ToString();
                else s = tale2[1].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentTale2
        {
            get
            {
                if (_index == 0) return tale1[2].ToString();
                else return tale2[2].ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = tale1[2].ToString();
                else s = tale2[2].ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string ContentCen
        {
            get
            {
                if (_index == 0) return center1.ToString();
                else return center2.ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = center1.ToString();
                else s = center2.ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string LeftTop
        {
            get
            {
                if (_index == 0) return CheckValid((talents1[0] + portret1[0])).ToString();
                else return CheckValid((talents2[0] + portret2[0])).ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = CheckValid((talents1[0] + portret1[0])).ToString();
                else s = CheckValid((talents2[0] + portret2[0])).ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string RightTop
        {
            get
            {
                if (_index == 0) return CheckValid((talents1[0] + finance1[0])).ToString();
                else return CheckValid((talents2[0] + finance2[0])).ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = CheckValid((talents1[0] + finance1[0])).ToString();
                else s = CheckValid((talents2[0] + finance1[0])).ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string RightBottom
        {
            get
            {
                if (_index == 0) return CheckValid((tale1[0] + finance1[0])).ToString();
                else return CheckValid((tale2[0] + finance2[0])).ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = CheckValid((tale1[0] + finance1[0])).ToString();
                else s = CheckValid((tale2[0] + finance2[0])).ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        public string LeftBottom
        {
            get
            {
                if (_index == 0) return CheckValid((tale1[0] + portret1[0])).ToString();
                else return CheckValid((tale2[0] + portret2[0])).ToString();
            }
            set
            {
                string s;
                if (_index == 0) s = CheckValid((tale1[0] + portret1[0])).ToString();
                else s = CheckValid((tale2[0] + portret2[0])).ToString();
                s = value;
                OnPropertyChanged(s);
            }
        }
        // Видимість поля для користувача
        public string IsUsernameNeed
        {
            get
            {
                if (_index == 0 && _user_name != null)
                {
                    return "Visible";
                }
                else
                return "Collapsed";

            }
        }

        // Функціональні методи
        public static void SaveToPdf(StackPanel panel)
        {
            try
            {
                double startX = panel.ActualWidth / 2;
                double startY = panel.ActualHeight / 2; 
                double width = panel.ActualWidth - startX; 
                double height = panel.ActualHeight - startY;
                Rect rect = new Rect(startX, startY, width, height);
                RenderTargetBitmap renderBitmap = new RenderTargetBitmap(
                    (int)(rect.Width * 4.01), (int)(rect.Height * 4.01),
                    384d, 384d, PixelFormats.Pbgra32);
                DrawingVisual drawingVisual = new DrawingVisual();
                using (DrawingContext drawingContext = drawingVisual.RenderOpen())
                {
                    VisualBrush visualBrush = new VisualBrush(panel);
                    drawingContext.DrawRectangle(visualBrush, null, new Rect(new Point(), rect.Size));
                }
                renderBitmap.Render(drawingVisual);
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(renderBitmap));
                using (MemoryStream ms = new MemoryStream())
                {
                    encoder.Save(ms);
                    ms.Position = 0;
                    Document document = new Document(new iTextSharp.text.Rectangle(0, 0, (float)rect.Width, (float)rect.Height), 0, 0, 0, 0);
                    PdfWriter writer = PdfWriter.GetInstance(document, new FileStream("Matrix.pdf", FileMode.Create));
                    document.Open();
                    iTextSharp.text.Image pdfImage = iTextSharp.text.Image.GetInstance(ms);
                    pdfImage.ScaleAbsolute((float)rect.Width, (float)rect.Height);
                    document.Add(pdfImage);
                    document.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public static List<Arcane> ReadFromJsonFile()
        {
            string jsonFromFile = File.ReadAllText("Arcanes.json");
            List<Arcane> objects = JsonConvert.DeserializeObject<List<Arcane>>(jsonFromFile);
            return objects;
        }
        public static int CheckValid(int it)
        {
            if (it > 22) it = it / 10 + it % 10;
            return it;
        }
        public void GetData()
        {
            if (_index == 0)
            {
                finance1 = _matrix1.ParseFinance();
                portret1 = _matrix1.ParsePortret();
                talents1 = _matrix1.ParseTalents();
                tale1 = _matrix1.ParseTale();
                center1 = _matrix1.ParseCenter();
            }
            else
            {
                finance2 = _matrix3.ParseFinance();
                portret2 = _matrix3.ParsePortret();
                talents2 = _matrix3.ParseTalents();
                tale2 = _matrix3.ParseTale();
                center2 = _matrix3.ParseCenter();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
    }
}
