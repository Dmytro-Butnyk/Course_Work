﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Printing;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Coursework.Model;

namespace Coursework.ViewModel
{
    public class ViewModelMain : INotifyPropertyChanged
    {
        private DataService _dataService;
        private int _selectedIndex;
        private Arcane _selectedArcane;
        private string _user_name;
        private Frame _frame;
        public RelayCommand _windowDescription;
        private RelayCommand _calculateCommand;
        public ObservableCollection<Arcane> Arcanes { get; set; }
        public ObservableCollection<string> ComboBoxItems { get; set; }
        
        public ViewModelMain(DataService dataService)
        {
            Arcanes = ReadFromJsonFile();
            ComboBoxItems = new ObservableCollection<string> { 
            "Індивідуальна матриця долі",
            "Матриця сумісності"
            };
            _dataService = dataService;
            dataService.matrix1 = new Matrix_Individual();
            dataService.matrix2 = new Matrix_Individual();
        }
        // Приймає значення індексу комбобокса
        public int SelectedIndex
        {
            get => _selectedIndex;
            set
            {
                _selectedIndex = value;
                OnPropertyChanged("SelectedIndex");
                OnPropertyChanged("IsSecondThreeVisible");
                OnPropertyChanged("IsUserNameNeed");
            }
        }
        public Arcane SelectedArcane
        {
            get { return _selectedArcane; }
            set
            {
                _selectedArcane = value;
                OnPropertyChanged("SelectedArcane");
            }
        }
        // Приймає значення ім'я користувача
        public string User_Name
        {
            get => _user_name;
            set
            {
                _user_name = value;
                OnPropertyChanged("User_Name");
            }
        }
        public Frame  Frame
        {
            get => _frame;
            set
            {
                _frame = value;
                OnPropertyChanged("Frame");
            }
        }
        public RelayCommand WindowDescription
        {
            get
            {
                return _windowDescription ?? (_windowDescription = new RelayCommand(obj =>
                {
                    if(SelectedArcane != null)
                    {
                        Description description = new Description(this);
                        description.Show();
                    }
                    else
                    {
                        MessageBox.Show("Оберіть правильний аркан!");
                    }
                }
                ));
            }
        }
        // Команда для кнопки, яка виконує перехід на нове вікно
        public RelayCommand CalculateCommand
        {
            set { _calculateCommand = value; }

            get
            {
                return _calculateCommand ?? (_calculateCommand = new RelayCommand(obj =>
                {

                    if (SelectedIndex == 0 && ValidateDate(Individual1))
                    {
                        _dataService.User_Name = _user_name;
                        var vievmodel2 = new ViewModelInformation(_dataService);
                        _dataService.InfoFrame = new Info(_dataService);
                        Frame.Content = _dataService.InfoFrame;
                    }
                    else if (SelectedIndex == 1 && ValidateDate(Individual2) && ValidateDate(Individual1))
                    {
                        _dataService.User_Name = _user_name;
                        var vievmodel2 = new ViewModelInformation(_dataService);
                        _dataService.InfoFrame = new Info(_dataService);
                        Frame.Content = _dataService.InfoFrame;
                    }
                    else
                    {
                        MessageBox.Show("ENTER RIGHT DATA");
                    }
}
                ));
            } 
        }
        // Зчитування арканів з .json файла
        public static ObservableCollection<Arcane> ReadFromJsonFile()
        {
            string jsonFromFile = File.ReadAllText("Arcanes.json");
            ObservableCollection<Arcane> objects = JsonConvert.DeserializeObject<ObservableCollection<Arcane>>(jsonFromFile);
            return objects;
        }
        public string IsUserNameNeed
        {
            get
            {
                if (SelectedIndex == 1)
                {
                    return "Collapsed";
                }
                else
                return "Visible";

            }
        }
        // Метод для виводу полів для матриці сумісності

        public string DescriptionArcaneNameNumber
        {
            get
            {
                    return SelectedArcane.A_Num + " : " + SelectedArcane.A_Name;
            }
        }
        public string DescriptionArcaneGeneral
        {
            get
            {
                return SelectedArcane.A_General_Description;
            }
        }
        public string DescriptionArcaneDetailed
        {
            get
            {
                return SelectedArcane.A_Detailed_Description;
            }
        }
        public string DescriptionArcaneImage
        {
            get
            {
                return SelectedArcane.A_Path_Image;
            }
        }

        public string IsSecondThreeVisible
        {
            get
            {
                if (SelectedIndex == 1)
                {
                    _dataService.Index = 1; 
                    return "Visible";
                }
                else
                    _dataService.Index = 0; 
                    return "Collapsed";

            }
        }
        public Matrix_Individual Individual1
        {
            get { return _dataService.matrix1; }
            set
            {
                _dataService.matrix1 = value;
                OnPropertyChanged("Matrix_Individual");
            }
        }
        public Matrix_Individual Individual2
        {
            get { return _dataService.matrix2; }
            set
            {
                _dataService.matrix2 = value;
                OnPropertyChanged("Matrix_Individual");
            }
        }
        // Функція, яка перевіряє валідність, введених у об'єкт класу, даних
        public bool ValidateDate(Matrix_Individual data)
        {
            

            if (data.Date_Month < 1 || data.Date_Month > 12)
            {
                return false;
            }

            int daysInMonth = DateTime.DaysInMonth(data.Date_Year, data.Date_Month);
            if (data.Date_Day < 1 || data.Date_Day > daysInMonth)
            {
                return false;
            }

            if(data.Date_Year > 9999 || data.Date_Year < 1000)
            {
                return false;
            }

            return true;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
    }
}
